DoPal - Mac Installation Instructions

1. Extract this zip file to a folder
2. Open Terminal
3. Navigate to the extracted folder:
   cd /path/to/DoPal-Mac
4. Make the app executable:
   chmod +x DoPal
5. Run the app:
   ./DoPal

If you get a "damaged" error:
1. Open Terminal
2. Navigate to the DoPal-Mac folder
3. Run: xattr -cr DoPal
4. Try running again: ./DoPal

The app will create a dopal.db file to save your progress.

Enjoy your virtual companion! 🐕 